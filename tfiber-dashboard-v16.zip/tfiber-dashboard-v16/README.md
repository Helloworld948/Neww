# T-Fiber End-User Connectivity Dashboard

React 18 + Highcharts 11, built with Vite. Frontend only: no backend, no database.
Data comes from the daily Excel report, converted to static JSON by a small Node script.

## Daily update (the normal routine)
1. Save the daily report as `data-source/daily_report.xlsx` (always the same name; replace the old file).
2. That is all, as long as `npm start` is running: the file is converted automatically and the open dashboard
   reloads itself within about 30 seconds (a green "New data loaded" banner appears; filters stay as they are).

## Run
    npm install
    npm start        # converts the Excel file, watches it for changes and starts the dashboard at http://localhost:3000
    npm run prod     # builds the site, converts into dist/data, watches the Excel file, serves dist/ at http://<this-pc>:4173

Other commands: `npm run data` (convert once), `npm run data:watch` (watch only), `npm run build`, `npm run preview`.
`npm start` and `npm run prod` also work when there is no Excel file yet: they use the JSON already in `public/data/`.

## What the Excel file must contain
- Sheet **Total Connections Detailed Data**, header on row 2 (same column names as the current report).
- A sheet named **Summary dd-Mmm-yyyy**, e.g. `Summary 16-Sep-2026`; if there are several, the latest date is used.
  Its first figures row (starting "Total user connectivity") feeds the "Verified" badges on the KPI cards and the
  "as on" date shown in the header.
- If a required column is missing or renamed, or the sheet is not found, the converter prints a clear error and the
  dashboard keeps showing the previous data (nothing is overwritten unless the whole conversion succeeds).

## Files written by the converter (`public/data/`, or `dist/data/` for `npm run prod`)
    connections.json        rows of the main sheet (selected columns, columnar; contact names/numbers are not exported)
    summary_reference.json  figures from the Summary sheet
    meta.json               generation time; the open page checks it every 30 s (`refreshSeconds` in src/config.js)

## Structure
    data-source/daily_report.xlsx   the daily report goes here (fixed name)
    scripts/convert.cjs             Excel -> JSON converter (also the watcher)
    scripts/dev.cjs                 npm start / npm run prod
    src/config.js        scope, SAC "received" statuses, Top-N values, refresh interval, filter list
    src/lib/mapper.js    original column names (incl. "Connection Catogory"), cleaning, alias tables
    src/lib/calc.js      filters, KPI rules, chart aggregation (pure functions)
    src/lib/export.js    CSV / Excel / PDF export of the Records table
    src/hooks.js         data loading + auto refresh (replace with an API call later; nothing else changes)
    src/components/      MultiSelect, KpiCard, ChartCard, RecordsTable, charts, tooltips

## Records table
Filter by ONT Serial Number, OLT IP Address, Service ID, GI / GP Name, GP/GI ONT LGD Code and PO Num (text, partial
match; comma-separated values match any). It respects the global filters. Export downloads every matching row as
CSV or Excel; PDF is capped at 3,000 rows.

## KPI rules
With the "PO only" switch they match the Summary sheet:
- Lit-Up = PO and Litup Yes; Yet to Lit-Up = PO and Litup No/blank
- Service Provisioned = PO, Lit-Up, and (Yes or Disconnected); Service Yet to Provision = Lit-Up minus Provisioned
- SAC Form Received = SAC Form Status in `sacReceived` (src/config.js); Yet to Receive = Service Provisioned minus SAC Received
- Disconnected = PO and Disconnection Status Yes
- "POS" in the original brief is treated as POC.

## Open item
SAC Form Received computes to 1,600 vs 1,606 in the 16-Sep summary (yet to receive 1,454 vs 1,448). The summary seems to
include a manual adjustment; the business team must confirm which statuses count as "received".
