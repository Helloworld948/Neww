import { useMemo } from 'react';
import { DonutChart } from './charts';
import { useFilteredApiRows, reload } from '../lib/recordsApi';
import { STATUS } from '../lib/theme';

const ORDER = [['UP', 'Up', '#16a34a'], ['DOWN', 'Down', STATUS.bad], ['', 'No status', '#94a3b8']];

/** Monitoring status of the services (final_status from the services API): Up / Down / no status. */
export default function MonitorStatusChart({ filters }) {
  const { api, rows } = useFilteredApiRows(filters);
  const { data, colors } = useMemo(() => {
    const n = { UP: 0, DOWN: 0, '': 0 };
    for (const r of rows) { const k = r.finalStatus === 'UP' || r.finalStatus === 'DOWN' ? r.finalStatus : ''; n[k] += 1; }
    const used = ORDER.filter(([k]) => n[k] > 0);
    return { data: used.map(([k, name]) => ({ name, y: n[k] })), colors: used.map(([, , c]) => c) };
  }, [rows]);

  if (api.status === 'loading') return <div className="state-inline"><i className="spin" /> Loading status from the services API…</div>;
  if (api.status === 'error') return <div className="state-inline error">{api.message}<button type="button" className="btn" onClick={reload}>Try again</button></div>;
  if (!data.length) return <div className="state-inline">No records.</div>;
  return <DonutChart data={data} centreLabel="services" colors={colors} height={270} />;
}
