import { Component, useMemo } from 'react';
import * as HighchartsReactModule from 'highcharts-react-official';
import Highcharts, { COLORS, PALETTE, STATUS, fmt } from '../lib/theme';

// highcharts-react-official is a CommonJS/UMD bundle. Depending on the Vite version (dev pre-bundling vs. production build) the
// default import is either the component itself or the whole module object ({ default: Component }) - unwrap it either way.
const isComponent = (c) => typeof c === 'function' || (c && typeof c === 'object' && '$$typeof' in c);
function resolveComponent(mod) {
  let c = mod;
  for (let i = 0; i < 4 && c && !isComponent(c); i += 1) c = c.default || c.HighchartsReact;
  if (!isComponent(c)) throw new Error('highcharts-react-official could not be loaded');
  return c;
}
const HighchartsReact = resolveComponent(HighchartsReactModule);

// one broken chart must not blank the whole dashboard
class ChartBoundary extends Component {
  constructor(props) { super(props); this.state = { failed: null }; }
  static getDerivedStateFromError(error) { return { failed: error }; }
  render() {
    return this.state.failed
      ? <div className="state-inline error">This chart could not be drawn ({String(this.state.failed.message || this.state.failed).slice(0, 120)}).</div>
      : this.props.children;
  }
}

const Chart = ({ options }) => (
  <ChartBoundary>
    <HighchartsReact highcharts={Highcharts} options={options} containerProps={{ style: { width: '100%' } }} />
  </ChartBoundary>
);

const clickToFilter = (onPick) => ({
  point: { events: { click() { onPick?.(this.name ?? this.category); } } },
  cursor: onPick ? 'pointer' : 'default',
});
const TIP_HEAD = '<span style="opacity:.75">{point.key}</span><br/>';
const label = { style: { fontSize: '11px', fontWeight: '600', color: COLORS.muted, textOutline: 'none' } };
const catAxis = { type: 'category', labels: { style: { color: COLORS.text, fontSize: '12px' } }, lineWidth: 0, tickLength: 0 };

/** Horizontal bar: category -> count. */
export function HBarChart({ data, onPick, color = COLORS.primary, rowHeight = 26 }) {
  const options = useMemo(() => ({
    chart: { type: 'bar', height: Math.max(160, data.length * rowHeight + 40) },
    xAxis: catAxis,
    yAxis: { min: 0, allowDecimals: false, labels: { enabled: false }, gridLineWidth: 0, maxPadding: 0.14 },
    legend: { enabled: false },
    tooltip: { headerFormat: TIP_HEAD, pointFormatter() { return `<b>${fmt(this.y)}</b> connections`; } },
    plotOptions: {
      bar: { borderRadius: 4, pointPadding: 0.14, groupPadding: 0.04, dataLabels: { enabled: true, formatter() { return fmt(this.y); }, ...label } },
      series: clickToFilter(onPick),
    },
    series: [{ name: 'Connections', color, data: data.map((d) => ({ ...d, color: d.name === 'Others' ? COLORS.slate : color })) }],
  }), [data, onPick, color, rowHeight]);
  return <Chart options={options} />;
}

/** Horizontal stacked bar: Lit-Up vs Yet to Lit-Up per group. */
export function LitStackChart({ data, onPick, rowHeight = 26, max }) {
  const options = useMemo(() => ({
    chart: { type: 'bar', height: Math.max(160, data.length * rowHeight + 70) },
    xAxis: { ...catAxis, categories: data.map((d) => d.name) },
    yAxis: { min: 0, allowDecimals: false, gridLineWidth: 0, labels: { enabled: false }, reversedStacks: false, maxPadding: 0.12, ...(max ? { max, endOnTick: false } : {}), stackLabels: { enabled: true, formatter() { return fmt(this.total); }, ...label } },
    legend: { enabled: true, align: 'right', verticalAlign: 'top', itemStyle: { fontSize: '12px', fontWeight: '500' } },
    tooltip: {
      shared: true,
      formatter() {
        const lit = this.points.find((p) => p.series.name === 'Lit-Up')?.y || 0;
        const total = this.points.reduce((s, p) => s + p.y, 0);
        return `<b>${this.x}</b><br/>Total <b>${fmt(total)}</b><br/>${this.points.map((p) => `<span style="color:${p.color}">●</span> ${p.series.name}: <b>${fmt(p.y)}</b>`).join('<br/>')}<br/>Lit-Up rate <b>${total ? ((lit / total) * 100).toFixed(0) : 0}%</b>`;
      },
    },
    plotOptions: { series: { stacking: 'normal', borderRadius: 0, pointPadding: 0.14, groupPadding: 0.04, ...clickToFilter(onPick) } },
    series: [
      { name: 'Lit-Up', color: STATUS.lit, data: data.map((d) => d.lit) },
      { name: 'Yet to Lit-Up', color: STATUS.yet, data: data.map((d) => d.yet) },
    ],
  }), [data, onPick, rowHeight, max]);
  return <Chart options={options} />;
}

/** Donut with the total in the centre; legend shows counts and share. */
export function DonutChart({ data, centreLabel, onPick, colors = PALETTE, height = 290 }) {
  const total = data.reduce((s, d) => s + d.y, 0);
  const options = useMemo(() => ({
    chart: { type: 'pie', height },
    colors,
    title: { text: `<span style="font-size:24px;font-weight:700;color:${COLORS.text}">${fmt(total)}</span><br/><span style="font-size:12px;color:${COLORS.muted}">${centreLabel}</span>`, useHTML: true, verticalAlign: 'middle', y: -20, align: 'center' },
    tooltip: { headerFormat: TIP_HEAD, pointFormatter() { return `<b>${fmt(this.y)}</b> (${this.percentage.toFixed(1)}%)`; } },
    legend: { enabled: true, align: 'center', verticalAlign: 'bottom', itemMarginBottom: 2, labelFormatter() { return `${this.name} · ${fmt(this.y)} (${this.percentage.toFixed(1)}%)`; } },
    plotOptions: { pie: { innerSize: '70%', size: '86%', center: ['50%', '42%'], showInLegend: true, dataLabels: { enabled: false }, borderWidth: 3, borderColor: '#fff' }, series: clickToFilter(onPick) },
    series: [{ name: 'Connections', colorByPoint: true, data }],
  }), [data, total, centreLabel, onPick, colors, height]);
  return <Chart options={options} />;
}

/** Simple column chart, one colour per bar. */
export function ColumnChart({ data, onPick, height = 280 }) {
  const options = useMemo(() => ({
    chart: { type: 'column', height },
    xAxis: { type: 'category', labels: { style: { color: COLORS.text, fontSize: '12px' } } },
    yAxis: { min: 0, allowDecimals: false, gridLineDashStyle: 'Dash' },
    legend: { enabled: false },
    tooltip: { headerFormat: TIP_HEAD, pointFormatter() { return `<b>${fmt(this.y)}</b> connections`; } },
    plotOptions: { column: { borderRadius: 5, pointPadding: 0.1, groupPadding: 0.12, colorByPoint: true, colors: PALETTE, dataLabels: { enabled: true, formatter() { return fmt(this.y); }, style: { fontSize: '12px', fontWeight: '600', color: COLORS.text, textOutline: 'none' } } }, series: clickToFilter(onPick) },
    series: [{ name: 'Connections', data }],
  }), [data, onPick, height]);
  return <Chart options={options} />;
}

/** Stacked column: PO vs POC per connection category. */
export function PoStackColumn({ data, onPick, height = 280 }) {
  const options = useMemo(() => ({
    chart: { type: 'column', height },
    xAxis: { categories: data.map((d) => d.name), labels: { style: { color: COLORS.text, fontSize: '12px' } } },
    yAxis: { min: 0, allowDecimals: false, gridLineDashStyle: 'Dash', stackLabels: { enabled: true, formatter() { return fmt(this.total); }, ...label } },
    legend: { enabled: true, itemStyle: { fontSize: '12px', fontWeight: '500' } },
    tooltip: { shared: true, formatter() { return `<b>${this.x}</b><br/>${this.points.map((p) => `<span style="color:${p.color}">●</span> ${p.series.name}: <b>${fmt(p.y)}</b>`).join('<br/>')}`; } },
    plotOptions: { column: { stacking: 'normal', borderRadius: 0, pointPadding: 0.12, groupPadding: 0.12 }, series: clickToFilter(onPick) },
    series: [
      { name: 'PO', color: STATUS.po, data: data.map((d) => d.PO || 0) },
      { name: 'POC', color: STATUS.poc, data: data.map((d) => d.POC || 0) },
    ],
  }), [data, onPick, height]);
  return <Chart options={options} />;
}

/** Rollout pipeline: PO -> Lit-Up -> Service Provisioned -> SAC Received, with step conversion. */
export function PipelineChart({ steps }) {
  const options = useMemo(() => {
    const colors = ['#1d4ed8', '#2563eb', '#0d9488', '#14b8a6'];
    return {
      chart: { type: 'bar', height: 270, spacingRight: 24 },
      xAxis: { categories: steps.map((s) => s.name), lineWidth: 0, tickLength: 0, labels: { style: { color: COLORS.text, fontSize: '13px', fontWeight: '600' } } },
      yAxis: { min: 0, gridLineWidth: 0, labels: { enabled: false }, maxPadding: 0.12 },
      legend: { enabled: false },
      tooltip: { headerFormat: TIP_HEAD, pointFormatter() { return `<b>${fmt(this.y)}</b>${this.conv != null ? ` · ${this.conv}% of previous step` : ''}`; } },
      plotOptions: {
        bar: {
          borderRadius: 6, pointPadding: 0.12, groupPadding: 0.02, colorByPoint: true, colors,
          dataLabels: { enabled: true, useHTML: true, formatter() { return `<span style="font-size:15px;font-weight:700;color:${COLORS.text}">${fmt(this.y)}</span>${this.point.conv != null ? ` <span style="font-size:12px;font-weight:600;color:${COLORS.muted}">${this.point.conv}%</span>` : ''}`; }, style: { textOutline: 'none' } },
        },
      },
      series: [{ name: 'Connections', data: steps.map((s) => ({ name: s.name, y: s.value, conv: s.conv })) }],
    };
  }, [steps]);
  return <Chart options={options} />;
}
