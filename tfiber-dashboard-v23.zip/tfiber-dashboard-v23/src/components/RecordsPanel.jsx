import RecordsTable from './RecordsTable';
import { useFilteredApiRows, reload } from '../lib/recordsApi';
import { fmt } from '../lib/theme';

/** Loads the Records table data from the API, applies the dashboard filters that exist in it, and shows loading / error states. */
export default function RecordsPanel({ filters, context }) {
  const { api, rows, ignored } = useFilteredApiRows(filters);

  if (api.status === 'loading') {
    return <section className="card records"><header className="card-head"><h2>Records</h2></header><div className="state-inline"><i className="spin" /> Loading records from the services API…</div></section>;
  }
  if (api.status === 'error') {
    return (
      <section className="card records">
        <header className="card-head"><h2>Records</h2></header>
        <div className="state-inline error">
          <b>Could not load records.</b> {api.message}
          <div><button type="button" className="btn primary" onClick={reload}>Try again</button></div>
        </div>
      </section>
    );
  }
  const partial = api.count > api.received;
  const at = api.fetchedAt ? new Date(api.fetchedAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '';
  return (
    <>
      {(api.message || partial || ignored) && (
        <div className="notice slim">
          {api.message && <>Latest refresh failed ({api.message}); showing data from {at}. </>}
          {partial && <>The API reports {fmt(api.count)} records but returned {fmt(api.received)}. </>}
          {ignored && <>Solution Type / Delivery Mode filters do not apply to this table. </>}
        </div>
      )}
      <RecordsTable rows={rows} context={`${context} · Source: services API (${at}${api.refreshing ? ', refreshing…' : ''})`} onReload={reload} refreshing={api.refreshing} fetchedAt={api.fetchedAt} />
    </>
  );
}
