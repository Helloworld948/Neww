// Dashboard settings. Edit here; no other file needs to change.
export const APP_VERSION = 'v2.3';

export const config = {
  dataUrl: 'data/connections.json', // array of records, or { columns, rows }
  referenceUrl: 'data/summary_reference.json', // figures from the 'Summary dd-Mmm-yyyy' sheet
  metaUrl: 'data/meta.json',                   // written by scripts/convert.cjs; polled to detect a new report
  refreshSeconds: 30,                          // how often the open dashboard checks for new data
  asOfLabel: '16 Sep 2026',

  // Records table data (services API, latest export). Same-origin path; vite.config.js proxies it to RECORDS_API_URL (see .env)
  recordsApiUrl: '/api/services/latest/export',
  recordsRefreshSeconds: 300,           // the table re-reads the API this often while the page is open (0 = only on load / Reload button)
  recordsTimeoutSeconds: 120,
  // Live ONT status (POST {identifier: serial} -> response.results[0].status)
  statusApiUrl: '/api/device-status',   // same-origin path; vite.config.js proxies it to DEVICE_API_URL (see .env)
  statusSerialPrefixes: ['TJ'],         // only ONT serials starting with these are checked
  statusConcurrency: 1,                 // 1 = strictly one request after the other (raise only if the API copes with parallel calls)
  statusGapMs: 150,                     // pause between two requests
  statusRetries: 3,                     // extra attempts when a request fails (network, timeout, 429, 5xx) before showing Error
  statusRetryDelayMs: 800,              // wait before retry 1; doubles for each further retry
  statusTtlSeconds: 300,                // a checked status is reused for this long before it is checked again
  statusTimeoutSeconds: 20,

  // Scope: only these records are used by the dashboard
  scopeCategories: ['Household', 'Private Enterprise', 'GI-Enterprise'],
  scopePoStatus: ['PO', 'POC'],

  // SAC Form Status values that count as "received" (business team must confirm)
  sacReceived: ['Available', 'Over E-mail', 'Completed'],

  // Operator chart: show this many operators, group the rest as "Others"
  operatorTopN: 10,
  districtTopN: 15,
};

export const FILTERS = [
  { key: 'cat', label: 'Connection Category' },
  { key: 'dept', label: 'Department' },
  { key: 'po', label: 'PO Status' },
  { key: 'lco', label: 'LCO / MSI / TSP' },
  { key: 'lit', label: 'Lit-Up' },
  { key: 'sp', label: 'Service Provisioned' },
  { key: 'sol', label: 'Solution Type' },
  { key: 'mode', label: 'Delivery Mode' },
  { key: 'district', label: 'District' },
  { key: 'pkg', label: 'Package' },
  { key: 'op', label: 'LCO Operator' },
];
