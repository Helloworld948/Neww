import { useCallback, useEffect, useRef, useState } from 'react';
import { config } from './config';
import { loadRecords } from './lib/mapper';

const getJson = async (url, bust) => {
  const res = await fetch(bust ? `${url}${url.includes('?') ? '&' : '?'}t=${Date.now()}` : url, { cache: 'no-store' });
  if (!res.ok) throw new Error(`Could not load ${url} (${res.status})`);
  return res.json();
};

/**
 * Loads the static JSON files (no backend). While the page is open it checks data/meta.json every few seconds;
 * when scripts/convert.cjs has written a newer one (a new daily Excel report), the data is reloaded in place
 * and the current filters stay as they are.
 */
export function useDashboardData() {
  const [state, setState] = useState({ status: 'loading' });
  const seen = useRef(null);

  const load = useCallback(async () => {
    const [raw, reference, meta] = await Promise.all([
      getJson(config.dataUrl, true),
      getJson(config.referenceUrl, true).catch(() => null),
      getJson(config.metaUrl, true).catch(() => null),
    ]);
    const data = loadRecords(raw, config);
    seen.current = meta ? meta.generatedAt : null;
    setState({ status: 'ready', ...data, reference, meta, loadedAt: Date.now() });
  }, []);

  useEffect(() => {
    let alive = true;
    load().catch((e) => { if (alive) setState({ status: 'error', message: e.message }); });
    const id = setInterval(async () => {
      try {
        const meta = await getJson(config.metaUrl, true);
        if (alive && meta.generatedAt !== seen.current) await load();
      } catch (e) { /* no meta file or a half-written file: try again next time */ }
    }, config.refreshSeconds * 1000);
    return () => { alive = false; clearInterval(id); };
  }, [load]);

  return { ...state, reload: load };
}
