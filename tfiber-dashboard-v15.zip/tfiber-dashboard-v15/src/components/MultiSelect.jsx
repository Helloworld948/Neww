import { useEffect, useMemo, useRef, useState } from 'react';
import { fmt } from '../lib/theme';

export default function MultiSelect({ label, options, selected, onChange }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const ref = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    const onKey = (e) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('mousedown', onDoc); document.removeEventListener('keydown', onKey); };
  }, [open]);

  const visible = useMemo(() => {
    const t = q.trim().toLowerCase();
    return t ? options.filter((o) => o.value.toLowerCase().includes(t)) : options;
  }, [options, q]);

  const set = new Set(selected);
  const toggle = (v) => onChange(set.has(v) ? selected.filter((x) => x !== v) : [...selected, v]);
  const selectAll = () => onChange([...new Set([...selected, ...visible.map((o) => o.value)])]);

  return (
    <div className="ms" ref={ref}>
      <span className="ms-label">{label}</span>
      <button
        type="button"
        className={`ms-btn${selected.length ? ' is-active' : ''}`}
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
      >
        <span className="ms-value">
          {selected.length === 0 ? 'All' : selected.length === 1 ? selected[0] : `${selected.length} selected`}
        </span>
        <svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M2 4.5l4 4 4-4" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg>
      </button>

      {open && (
        <div className="ms-pop" role="listbox" aria-multiselectable="true">
          {options.length > 8 && (
            <input className="ms-search" autoFocus placeholder={`Search ${label.toLowerCase()}…`} value={q} onChange={(e) => setQ(e.target.value)} />
          )}
          <div className="ms-actions">
            <button type="button" onClick={selectAll}>Select all{q ? ' shown' : ''}</button>
            <button type="button" onClick={() => onChange([])}>Clear all</button>
          </div>
          <ul className="ms-list">
            {visible.map((o) => (
              <li key={o.value}>
                <label>
                  <input type="checkbox" checked={set.has(o.value)} onChange={() => toggle(o.value)} />
                  <span className="ms-opt">{o.value}</span>
                  <span className="ms-count">{fmt(o.count)}</span>
                </label>
              </li>
            ))}
            {visible.length === 0 && <li className="ms-empty">No matches</li>}
          </ul>
        </div>
      )}
    </div>
  );
}
