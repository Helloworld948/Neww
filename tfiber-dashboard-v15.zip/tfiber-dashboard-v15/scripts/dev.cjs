/*
 * One command for everything:
 *   npm start        converts data-source/daily_report.xlsx, watches it, and starts the dashboard (dev server)
 *   npm run prod     builds the site, converts into dist/data, watches the Excel file, and serves dist/ on your network
 */
var path = require('path');
var cp = require('child_process');
var fs = require('fs');
var converter = require('./convert.cjs');

var ROOT = path.resolve(__dirname, '..');
var prod = process.argv.indexOf('--prod') >= 0;
var vite = path.join(ROOT, 'node_modules', 'vite', 'bin', 'vite.js');

function run(args) {
  return cp.spawnSync(process.execPath, [vite].concat(args), { cwd: ROOT, stdio: 'inherit' });
}

var outDir = converter.DEFAULT_OUT;
var viteArgs = [];
if (prod) {
  console.log('[build] building the dashboard...');
  var b = run(['build']);
  if (b.status !== 0) process.exit(b.status || 1);
  outDir = path.join(ROOT, 'dist', 'data');
  fs.mkdirSync(outDir, { recursive: true });
  // keep the last good data when building without a new Excel file
  ['connections.json', 'summary_reference.json', 'meta.json'].forEach(function (f) {
    var src = path.join(converter.DEFAULT_OUT, f);
    if (fs.existsSync(src)) fs.copyFileSync(src, path.join(outDir, f));
  });
  viteArgs = ['preview', '--host', '--port', '4173'];
} else {
  viteArgs = ['--host'];
}

var stop = converter.watch({ out: outDir });
var child = cp.spawn(process.execPath, [vite].concat(viteArgs), { cwd: ROOT, stdio: 'inherit' });
function end(code) { stop(); try { child.kill(); } catch (e) { /* ignore */ } process.exit(code || 0); }
child.on('exit', function (code) { end(code); });
process.on('SIGINT', function () { end(0); });
process.on('SIGTERM', function () { end(0); });
